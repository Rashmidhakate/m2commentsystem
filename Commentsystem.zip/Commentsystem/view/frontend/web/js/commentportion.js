define([
   'ko',
   'uiComponent',
   'mage/url',
   'mage/storage',
   'jquery',
], function (ko, Component, urlBuilder,storage,jQuery) {
   'use strict';
   	var comments = ko.observableArray([]);
   	var replyComment = ko.observable(false);
	return Component.extend({

		defaults: {
		  template: 'Magento_Commentsystem/commentportion',
		},

		comments : ko.observableArray([]),

		replyComment : ko.observable(false),

		initialize: function () {
			this._super();
		},

		submitForm : function(formElement){
			var self = this;
			var saveData = {},
                    formDataArray = jQuery(formElement).serializeArray();
 
            formDataArray.forEach(function (entry) {
                saveData[entry.name] = entry.value;
            });
			jQuery.ajax({
				url: urlBuilder.build('commentsystem/index/save'),
				data: saveData,
				type: 'post',
				dataType: 'json',
				success: function (response) {
					jQuery('#commentForm').each(function(){
						this.reset();
					});
					jQuery('#commentId').val('0');
					self.showComments(response.parent_id);
				}
			});
		},

		showComments : function(commentId){
			var self = this;
			jQuery.ajax({
				url: urlBuilder.build('commentsystem/index/showcomments'),
				data: {parentId : commentId},
				type: 'POST',
				dataType: 'json',
				success: function (response) {
					if(commentId == 0){
						jQuery.each(response, function (i, v) {
							self.comments.push(v);
						});
					}else{

						jQuery('#reply_comment'+commentId).html(response);
						// jQuery.each(response, function (i, v) {
						// 	self.replyComment.push(v);
						// });
						console.log(commentId);
					}
					
					//jQuery('#showComments').html(response);
				}
			});
		},

		reply: function(){
			var commentId = jQuery(this).attr("id");
			jQuery('#commentId').val(commentId);
			jQuery('#name').focus();
		},
		getComments: function () {
			return comments;
        },
        replyComment : function () {
        	var self = this;
			return self.replyComment(true);
        },
	});
});