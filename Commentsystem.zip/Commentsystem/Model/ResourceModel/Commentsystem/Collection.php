<?php
namespace Magento\Commentsystem\Model\ResourceModel\Commentsystem;



class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
	protected $_idFieldName = 'id';
    protected function _construct()
    {
        $this->_init('Magento\Commentsystem\Model\Commentsystem','Magento\Commentsystem\Model\ResourceModel\Commentsystem');
    }
}