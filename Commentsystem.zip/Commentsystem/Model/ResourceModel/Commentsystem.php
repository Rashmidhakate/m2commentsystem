<?php
namespace Magento\Commentsystem\Model\ResourceModel;
  
use Magento\Framework\Model\ResourceModel\Db\AbstractDb;
  
class Commentsystem extends AbstractDb
{
    /**
     * Define main table
     */
    protected function _construct()
    {
        $this->_init('comment_system', 'id');
    }
}
