<?php
namespace Magento\Commentsystem\Model;
  
use Magento\Framework\Model\AbstractModel;
  
class Commentsystem extends AbstractModel
{
    /**
     * Define resource model
     */
    protected function _construct()
    {
        $this->_init('Magento\Commentsystem\Model\ResourceModel\Commentsystem');
    }
}
