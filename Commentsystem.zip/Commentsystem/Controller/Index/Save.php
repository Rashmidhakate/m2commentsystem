<?php 

namespace Magento\Commentsystem\Controller\Index;

class Save extends \Magento\Framework\App\Action\Action
{
	protected $resultPageFactory;
 
	public function __construct(
	   \Magento\Framework\App\Action\Context $context,
	   \Magento\Commentsystem\Model\Commentsystem $commentsystem,
	   \Magento\Framework\View\Result\PageFactory $resultPageFactory,
	   \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory
	)
	{
	   $this->resultPageFactory = $resultPageFactory;
	   $this->commentsystem = $commentsystem;
	   $this->resultJsonFactory = $resultJsonFactory;
	   parent::__construct($context);
	}

	public function execute()
	{
		$result = $this->resultJsonFactory->create();
		$formData = $this->getRequest()->getPostValue();
		$parentId = $formData["commentId"];
		$comment = $formData["comment"];
		$name = $formData["name"];
		try {
			$model = $this->commentsystem;
			$model->setParentId($parentId);
			$model->setComment($comment);
			$model->setSender($name);
			$model->save();
			$message = __(
				'Comment added successfully.'
			);
    		$this->messageManager->addSuccessMessage($message);
			$status = array(
				'error' => 0,
				'parent_id' => $parentId,
				'message' => $message
			);
		} catch(\Exception $e){
			$message = $e->getMessage();
			$this->messageManager->addException($e,$message);
			$status = array(
				'error' => 1,
				'parent_id' => $parentId,
				'message' => $message 
			);
		}
		return $this->getResponse()->representJson(
				$this->_objectManager->get(\Magento\Framework\Json\Helper\Data::class)->jsonEncode($status)
			);
	}
}