<?php 

namespace Magento\Commentsystem\Controller\Index;

class Showcomments extends \Magento\Framework\App\Action\Action
{
	protected $resultPageFactory;
 
	public function __construct(
	   \Magento\Framework\App\Action\Context $context,
	   \Magento\Commentsystem\Model\Commentsystem $commentsystem,
	   \Magento\Framework\View\Result\PageFactory $resultPageFactory,
	   \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory
	)
	{
	   $this->resultPageFactory = $resultPageFactory;
	   $this->commentsystem = $commentsystem;
	   $this->resultJsonFactory = $resultJsonFactory;
	   parent::__construct($context);
	}

	public function execute()
	{
		$formData = $this->getRequest()->getPostValue();
		$parentId = $formData["parentId"];
		$result = $this->resultJsonFactory->create();
		$commentCollection = $this->commentsystem->getCollection();
		$commentCollection->addFieldToFilter('parent_id',array('eq' => $parentId));
		$commentCollection->setOrder('id','DESC');
		$commentHTML = '';
		foreach($commentCollection as $comments){
			$response[] = [
				'parent_id' => $comments->getParentId(),
				'sender' => $comments->getSender(), 
				'date' => $comments->getDate(), 
				'comment' => $comments->getComment() , 
				'id' => $comments->getId()
			];
			// $commentHTML .= '
			// <div class="panel panel-primary">
			// <div class="panel-heading">By <b>'.$comments->getSender().'</b> on <i>'.$comments->getDate().'</i></div>
			// <div class="panel-body">'.$comments->getComment().'</div>
			// <div class="panel-footer" align="right"><button type="button" class="btn btn-primary reply" id="'.$comments->getId().'">Reply</button></div>
			// <div class="reply_div" data-bind="attr: {id: reply_comment'.$comments->getId().'},click:reply"></div>
			// </div> ';
		}
		$result = $result->setData($response);
		return $this->getResponse()->representJson(
				$this->_objectManager->get(\Magento\Framework\Json\Helper\Data::class)->jsonEncode($response)
			);
		//return $result;
	}
}